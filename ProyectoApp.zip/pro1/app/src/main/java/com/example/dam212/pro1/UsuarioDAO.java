package com.example.dam212.pro1;


public interface UsuarioDAO {
    Usuario getUsuario(String login, String password);
    boolean insertarUsuario(Usuario usr);

}


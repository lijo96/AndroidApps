package com.example.dam212.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class MainActivity extends AppCompatActivity {
    private cervezas appv;
    public final static String USUARIO = "usuario";
    public final static String NOMBRE = "nombre";
    public final static String ID = "id";

    public final static String LOGIN = "login";
    public final static String PASSWORD = "password";

    public final static String EMAIL = "email";
    public final static String PAIS= "pais";



    UsuarioDAOSQLite usrDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        copiarBD();
        this.usrDAO = new UsuarioDAOSQLite(this);
        xestionarEventos();
    }




    private void copiarBD() {
        String bddestino = "/data/data/" + getPackageName() + "/databases/"
                + cervezas.NOME_BD;
        File file = new File(bddestino);
        Log.d("DEPURACIÓN", "Ruta archivo BD: " + bddestino);
        if (file.exists()) {
            Toast.makeText(getApplicationContext(), "El Login ya exite, prueba con otro.", Toast.LENGTH_LONG).show();
            return; // XA EXISTE A BASE DE DATOS
        }




        String pathbd = "/data/data/" + getPackageName()
                + "/databases/";
        File filepathdb = new File(pathbd);
        filepathdb.mkdirs();




        InputStream inputstream;
        try {
            inputstream = getAssets().open(cervezas.NOME_BD);
            OutputStream outputstream = new FileOutputStream(bddestino);
            int tamread;
            byte[] buffer = new byte[2048];
            while ((tamread = inputstream.read(buffer)) > 0) {
                outputstream.write(buffer, 0, tamread);
            }
            inputstream.close();
            outputstream.flush();
            outputstream.close();
            Toast.makeText(getApplicationContext(), "BASE DE DATOS COPIADA", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void xestionarEventos() {
        Button btnAbrirBD = (Button) findViewById(R.id.button);
        btnAbrirBD.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                iniciarSesion();
            }
        });

        Button btnNuevoUsuario = (Button) findViewById(R.id.button2);
        btnNuevoUsuario.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                nuevoUsuario();
            }
        });
    }

    void nuevoUsuario(){
        Toast.makeText(getApplicationContext(), "Formulario de registro de nuevo usuario.", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, NuevoUsuario.class);
        startActivity(intent);
        // No se finaliza la Activity en este caso.
    }

    void iniciarSesion() {
        String login = ((EditText) findViewById(R.id.editText)).getText().toString();
        String password = ((EditText) findViewById(R.id.editText2)).getText().toString();
        Usuario usr = this.usrDAO.getUsuario(login, password);

        if (usr != null) {

            Log.d("DEPURACIÓN", "Nombre usr: "+ usr.getNombre());
            Toast.makeText(getApplicationContext(), "Iniciando sesión.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, BusquedaCervezas.class);

            intent.putExtra(this.USUARIO, usr);
            /*intent.putExtra(this.NOMBRE, usr.getNombre());
            intent.putExtra(this.ID, usr.getId());
            intent.putExtra(this.LOGIN, usr.getLogin());
            intent.putExtra(this.PASSWORD, usr.getPassword());
            intent.putExtra(this.EMAIL, usr.getEmail());
            intent.putExtra(this.PAIS, usr.getPais());*/


            startActivity(intent);
            finish();
        } else {
            MensajeDialogo d= new MensajeDialogo();
            android.app.FragmentManager fm= this.getFragmentManager();
            d.show(fm,"errorLogin");
        }
    }
}

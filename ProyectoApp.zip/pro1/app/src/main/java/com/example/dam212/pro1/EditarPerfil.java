package com.example.dam212.pro1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class EditarPerfil extends AppCompatActivity {
    EditText editText31, editText41, editText51, getEditText61, email;
    Spinner pais;
    String paisSpinner;
    Intent intent2;
    Button btnregistrarusuario1;
    int checkBox11, id;
    public final static String USUARIO = "Usuario";
    UsuarioDAOSQLite usrDAO;
    private cervezas appv;
    Usuario usr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editar_perfil);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        intent2 = getIntent();
        usr = (Usuario) intent2.getExtras().getSerializable(MainActivity.USUARIO);
        this.usrDAO = new UsuarioDAOSQLite(this);
        xestionarEventos();

        Spinner spinpais = (Spinner) findViewById(R.id.pais);
        spinpais.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                // TODO Auto-generated method stub
                paisSpinner = parent.getItemAtPosition(pos).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
// FALLO AQUI
        editText31= (EditText) findViewById(R.id.editText31);
        editText41= (EditText) findViewById(R.id.editText41);
        editText51= (EditText) findViewById(R.id.editText51);
        email = (EditText) findViewById(R.id.editText61);
        pais = (Spinner) findViewById(R.id.pais);



        if (usr!=null){
            editText31.append("" + usr.getNombre());
            editText41.append("" + usr.getLogin());
            editText51.append("" + usr.getPassword());;
            email.append("" + usr.getEmail());}
        else
            Log.d("DEPURACIÓN", "Usuario nulo");

    }



    void xestionarEventos() {
        btnregistrarusuario1 = (Button) findViewById(R.id.btnregistrarusuario1);

        editText31 = (EditText) findViewById(R.id.editText31);
        editText41 = (EditText) findViewById(R.id.editText41);
        editText51 = (EditText) findViewById(R.id.editText51);
        email = (EditText) findViewById(R.id.editText61);
        pais = (Spinner) findViewById(R.id.pais);

        editText31.setText(intent2.getExtras().getString(MainActivity.NOMBRE));
        editText41.setText(intent2.getExtras().getString(MainActivity.LOGIN));
        editText51.setText(intent2.getExtras().getString(MainActivity.PASSWORD));
        email.setText(intent2.getExtras().getString(MainActivity.EMAIL));
        id = intent2.getExtras().getInt(MainActivity.ID);

        String myString = intent2.getExtras().getString(MainActivity.PAIS);
        ArrayAdapter myAdap = (ArrayAdapter) pais.getAdapter();
        int spinnerPosition = myAdap.getPosition(myString);
        pais.setSelection(spinnerPosition);


        //Marcar por defecto la opción Nonstop y Roundtrip
        this.btnregistrarusuario1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent2.putExtra("Nombre", editText41.getText().toString());
                setResult(RESULT_OK, intent2);
                actualizar();
            }

        });

    }

    public void controlarCheckBox(View view) {
        CheckBox check = (CheckBox) view;
        if (check.isChecked())
            checkBox11 = 1;
        else
            checkBox11 = 0;
    }

    void actualizar() {
        String nombre = ((EditText) findViewById(R.id.editText31)).getText().toString();
        String login = ((EditText) findViewById(R.id.editText41)).getText().toString();
        String password = ((EditText) findViewById(R.id.editText51)).getText().toString();
        String email = ((EditText) findViewById(R.id.editText61)).getText().toString();

        String query = "";
        //Roundtrip

        if(pais.equals("")){
            Toast.makeText(EditarPerfil.this, "Escoge un país!", Toast.LENGTH_LONG).show();
        }else {
            if (nombre.equals("") || password.equals("")) {
                Toast.makeText(EditarPerfil.this, "Completa los campos de Login y Password!", Toast.LENGTH_LONG).show();
            } else if (password.length() < 6) {
                Toast.makeText(EditarPerfil.this, "La contraseña tiene que tener como mínimo 6 caracteres!", Toast.LENGTH_LONG).show();
            } else {
                if (checkBox11 == 1) {
                    query = "UPDATE usuario SET nombre = '" + nombre + "', login = '" + login + "', password = '" + password +
                            "', email = '" + email + "', pais = '" + paisSpinner + "' WHERE id = '" + id + "'";

                    this.appv = new cervezas(getApplicationContext());
                    SQLiteDatabase sqlLiteDB = appv.getWritableDatabase();
                    Cursor cursor = sqlLiteDB.rawQuery(query, null);
                    Log.d("DEPURACIÓN", "Nº filas: " + cursor.getCount());
                    finish();
                    boolean insercion = true;
                    //Notificación de la inserción.
                    if (insercion)
                        Toast.makeText(getApplicationContext(), "24" +
                                "LAC Usuario actualizado correctamente.", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getApplicationContext(), "Error en la actualización del usuario.", Toast.LENGTH_LONG).show();
                    //Ir a la ventana de inicio de sesión y finalizar la Activity.


                } else {
                    Toast.makeText(EditarPerfil.this, "No has aceptado los términos!", Toast.LENGTH_LONG).show();
                }
            }
        }

        Log.d("DEPURACIÓN", "Consulta: " + query);
        //Ir a la Activity Resultado de la búsqueda. No se finaliza BusquedaVuelos.
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        boolean resultado = false;
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
            default:
                resultado = super.onOptionsItemSelected(item);

                intent2.putExtra("Nombre", usr.toString());
                setResult(RESULT_OK, intent2);

        }
        return resultado;
    }


    //public void onPecharClick(View view) {
        // Forma_Pechar_Activity = " Premendo botón Pechar";
      //  EditText editText31 = (EditText) findViewById(R.id.editText31);

     //   Intent datos_volta = new Intent();
      //  datos_volta.putExtra("Nombre", editText31.getText().toString());
      //  setResult(RESULT_OK, datos_volta);
       // finish();

   // }

}

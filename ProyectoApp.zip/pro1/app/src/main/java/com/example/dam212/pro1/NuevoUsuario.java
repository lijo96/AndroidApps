package com.example.dam212.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class NuevoUsuario extends AppCompatActivity {
    private cervezas appv;
    UsuarioDAOSQLite usrDAO;
    String pais;
    int checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.usrDAO = new UsuarioDAOSQLite(this);
        xestionarEventos();

        Spinner spinpais = (Spinner) findViewById(R.id.spinner);
        spinpais.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                // TODO Auto-generated method stub
                pais = parent.getItemAtPosition(pos).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean resultado = false;
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
            default:
                resultado = super.onOptionsItemSelected(item);


        }
        return resultado;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }


    void xestionarEventos() {
        Button btnNuevoUsuario = (Button) findViewById(R.id.button3);
        btnNuevoUsuario.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                crearUsuario();
            }
        });
    }

    public void controlarCheckBox(View view) {
        CheckBox check = (CheckBox) view;
        if (check.isChecked())
            checkBox = 1;
        else
            checkBox = 0;
    }

    void crearUsuario() {
        String nombre = ((EditText) findViewById(R.id.editText3)).getText().toString();
        String login = ((EditText) findViewById(R.id.editText4)).getText().toString();
        String password = ((EditText) findViewById(R.id.editText5)).getText().toString();
        String email = ((EditText) findViewById(R.id.editText6)).getText().toString();

    	/*Creación el objeto usuario. Dado que id es autoincrementable en la base de datos
    	el valor del campo id no será procesado en el método de inserción de usuario.
    	Por lo tanto, se le pasará 0, o cualquier otro valor.*/
        if(pais.equals("")){
            Toast.makeText(NuevoUsuario.this, "Escoge un país!", Toast.LENGTH_LONG).show();
        }else {
            if (login.equals("") || password.equals("")) {
                Toast.makeText(NuevoUsuario.this, "Completa los campos de Login y Password!", Toast.LENGTH_LONG).show();
            } else if (password.length() < 6) {
                Toast.makeText(NuevoUsuario.this, "La contraseña tiene que tener como mínimo 6 caracteres!", Toast.LENGTH_LONG).show();
            } else {
                if (checkBox == 1) {
                    Usuario usr = new Usuario(nombre, login, password, 0, email, pais);
                    boolean insercion = this.usrDAO.insertarUsuario(usr);
                    //Notificación de la inserción.
                    if (insercion)
                        Toast.makeText(getApplicationContext(), "24LAC Nuevo usuario registrado.", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getApplicationContext(), "Error en el registro de usuario.", Toast.LENGTH_LONG).show();
                    //Ir a la ventana de inicio de sesión y finalizar la Activity.
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(NuevoUsuario.this, "No has aceptado los términos!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

}

package com.example.dam212.pro1;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class UsuarioDAOSQLite implements UsuarioDAO {
    private cervezas appv;
    private Context context;


    UsuarioDAOSQLite(Context context){
        this.context=context;
        this.appv = new cervezas(this.context);
    }

    public boolean insertarUsuario(Usuario usr) {
        boolean resultado = true;
        SQLiteDatabase sqlLiteDB = appv.getWritableDatabase();
        String sql = "INSERT INTO Usuario(nombre, login, password, email, pais) VALUES (?,?,?,?,?)";
        SQLiteStatement statement = sqlLiteDB.compileStatement(sql);
        statement.bindString(1, usr.getNombre());
        statement.bindString(2, usr.getLogin());
        statement.bindString(3, usr.getPassword());
        statement.bindString(4, usr.getEmail());
        statement.bindString(5,usr.getPais());
        long idFila1 = statement.executeInsert();
        if (idFila1 != -1) {
        /*Comprobación de la lista de usuarios. El siguiente código tiene como finalidad
        mostrar en el logcat el usuario que se acaba de insertar.
         */
            String usuarios = "";
            Cursor cursor = sqlLiteDB.rawQuery("select * from Usuario", null);
            if (cursor.moveToFirst()) {                // Se non ten datos xa non entra
                while (!cursor.isAfterLast()) {     // Quédase no bucle ata que remata de percorrer o cursor. Fixarse que leva un ! (not) diante
                    usuarios += " " + cursor.getString(0) + " | " + cursor.getString(1) + " | " + cursor.getString(2) + " | " + cursor.getString(3)
                            + " | " + cursor.getString(4) + " | " + cursor.getString(5) + "\n";
                    cursor.moveToNext();
                }
            }
            Log.d("DEPURACÍON", "Resultado inserción: " + usuarios);
        } else {
            resultado = false;
        }
        return resultado;
    }

    void depuracion(String consulta, String[] param) {
        String texto = "Consulta: " + consulta + " Valores: ";
        for (String p : param) {
            texto += p + " ";
        }
        Log.d("DEPURACIÓN", texto);
    }

    public Usuario getUsuario(String login, String password) {
        Usuario resultado = null;
        SQLiteDatabase sqlLiteDB = appv.getWritableDatabase();
        String[] param = {login, password};
        String consulta = "SELECT * FROM usuario WHERE login=? AND password=?";
        Cursor cursor = sqlLiteDB.rawQuery(consulta, param);
        this.depuracion(consulta, param);
        Log.d("DEPURACIÓN", "Nº filas: " + cursor.getCount());
        if (cursor.moveToFirst()) {
            resultado= new Usuario(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3), cursor.getString(4), cursor.getString(5));
        }
        return resultado;
    }
}



package com.example.dam212.pro1;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

public class Internacional extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.buscar_cervezas);
        setContentView(R.layout.editar_perfil);
        setContentView(R.layout.elemento_lista);
        setContentView(R.layout.login);
        setContentView(R.layout.registro);
        setContentView(R.layout.resultado_busqueda);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_busqueda, menu);
        return true;
    }

//    public void onBotonClick(View v) {
//        Toast.makeText(this, R.string., Toast.LENGTH_SHORT).show();
//    }


}


package com.example.dam212.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;


public class
BusquedaCervezas extends AppCompatActivity implements Serializable {
    Button buttonBuscar;
    Spinner clase;
    String tipo, nombre, login, password, email, pais;
    int checkBox, id;
    EditText editText31, editText41, editText51, getEditText61;

    public final static String NOMBRE = "nombre";
    public final static String LOGIN = "login";
    public final static String PASSWORD = "password";
    public final static String EMAIL = "email";
    public final static String PAIS = "pais";
    public final static String ID = "id";
    Usuario usr;
    private static final int COD_PETICION = 33;
    public final static String CONSULTA = "consulta";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buscar_cervezas);
        Intent intent = getIntent();
        usr=(Usuario) intent.getExtras().getSerializable(MainActivity.USUARIO);
      String nuevoTitulo = getResources().getText(R.string.app_name)
                + ": " + usr.getNombre();

     setTitle(nuevoTitulo);

    //  nombre = intent.getExtras().getString(MainActivity.NOMBRE);
  //     login = intent.getExtras().getString(MainActivity.LOGIN);
  //    password = intent.getExtras().getString(MainActivity.PASSWORD);
  //    email = intent.getExtras().getString(MainActivity.EMAIL);
  //    pais = intent.getExtras().getString(MainActivity.PAIS);
  //     id = intent.getExtras().getInt(MainActivity.ID);

        xestionarEventos();
    }


    void xestionarEventos() {
        buttonBuscar = (Button) findViewById(R.id.buttonBuscar);
        clase=(Spinner) findViewById(R.id.spintipo);
        Spinner spintipo = (Spinner) findViewById(R.id.spintipo);
        spintipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                // TODO Auto-generated method stub
                tipo = parent.getItemAtPosition(pos).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        //Marcar por defecto la opción Nonstop y Roundtrip
        this.buttonBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String modelo = ((EditText) findViewById(R.id.edit_from)).getText().toString();

                if (modelo.equals("")) {
                    Toast.makeText(BusquedaCervezas.this , "Introduce el nombre de una cerveza de la lista",Toast.LENGTH_LONG).show();
                } else {
                    if (tipo.equals("")){
                        Toast.makeText(BusquedaCervezas.this , "Selecciona un tipo!",Toast.LENGTH_LONG).show();
                    }else {
                        buscarCervezas();
                    }
                }
            }
        });
    }

    public void controlarCheckBox(View view) {
        CheckBox check = (CheckBox) view;
        if (check.isChecked())
            checkBox = 1;
        else
            checkBox = 0;
    }

    public void buscarCervezas() {
        /*Es necesario añadir a la consulta un campo _id para poder construir
         * en ResultadoBusqueda un ListAdapter directametne a partir del
         * resultado de la consulta*/

        String nombre = ((EditText) findViewById(R.id.edit_from)).getText().toString();

        String query = "";
        //Roundtrip
        if (checkBox == 1) {
            query = "SELECT cerveza_id AS _id, nombre, precio, tipo,  alcohol FROM cervezas " +
                    "WHERE nombre = '" + nombre + "' AND tipo = '" + tipo +
                    "' AND alcohol = 'si'";
        } else {
            query = "SELECT cerveza_id AS _id, nombre, precio, tipo,  alcohol FROM cervezas " +
                    "WHERE nombre = '" + nombre + "' AND tipo = '" + tipo + "'";
        }
        Log.d("DEPURACIÓN", "Consulta: " + query);
        //Ir a la Activity Resultado de la búsqueda. No se finaliza BusquedaVuelos.
        Intent intent = new Intent(this, ResultadoBusqueda.class);
        intent.putExtra(this.CONSULTA, query);
        //startActivity(intent);
        startActivityForResult(intent, COD_PETICION);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:
                //Ir a la ventana de inicio de sesión y finalizar la Activity.
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.editar_perfil:
                //Código relativo a la edición de perfil de usuario.
                Intent intent2 = new Intent(this, EditarPerfil.class);

          //      intent2.putExtra(this.NOMBRE, nombre);
             //   intent2.putExtra(this.LOGIN, login);
            //    intent2.putExtra(this.PASSWORD, password);
            //    intent2.putExtra(this.EMAIL, email);
           //     intent2.putExtra(this.PAIS, pais);
            //    intent2.putExtra(this.ID, id);

                intent2.putExtra(MainActivity.USUARIO, usr);

                startActivityForResult(intent2, COD_PETICION);
                break;
//            case R.id.pedidos:
            //Codigo para ver los pedidos del usuario!
        }
        return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == COD_PETICION) {
            if (resultCode == RESULT_OK) {
                if (data.hasExtra("Nombre"));


            } else
                Toast.makeText(this, "Saliste de la activity sin modificar el usuario", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_busqueda, menu);
        return true;
    }


}
